package com.example.finalniy_calculatorus

import android.animation.ArgbEvaluator
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.ContextCompat

private const val TAG = "MainActivity"
private const val INITIAL_TIP_PERCENT = 15
class MainActivity : AppCompatActivity() {
    private lateinit var etBaseAmount: EditText
    private lateinit var seekBarComission: SeekBar
    private lateinit var tvComissionPercentLabel: TextView
    private lateinit var tvComissionAmount: TextView
    private lateinit var tvTotalAmount: TextView
    private lateinit var tvComissionDescription: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etBaseAmount = findViewById(R.id.etBaseAmount)
        seekBarComission = findViewById(R.id.seekBarComission)
        tvComissionPercentLabel = findViewById(R.id.tvComissionPercentLabel)
        tvComissionAmount = findViewById(R.id.tvComissionAmount)
        tvTotalAmount = findViewById(R.id.tvTotalAmount)
        tvComissionDescription = findViewById(R.id.tvComissionDescription)

        seekBarComission.progress = INITIAL_TIP_PERCENT
        tvComissionPercentLabel.text = "$INITIAL_TIP_PERCENT%"
        updateComissionDescription(INITIAL_TIP_PERCENT)
        seekBarComission.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                Log.i(TAG, "OnProgressChanged $progress")
                tvComissionPercentLabel.text = "$progress%"
                computeTipAndTotal()
                updateComissionDescription(progress)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}

            override fun onStopTrackingTouch(p0: SeekBar?) {}

        })
        etBaseAmount.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(s: Editable?) {
                Log.i(TAG, "afterTextChanged $s")
                computeTipAndTotal()
            }

        })
    }

    private fun updateComissionDescription(commisionPercent: Int) {
        val comissionDescription = when (commisionPercent) {
            in 0..9 -> "Пенсионный"
            in 10..14 -> "Оптимальный"
            in 15..19 -> "Комфорт"
            in 20..24 -> "Бизнесмен"
            else -> "Максимум"
        }
        tvComissionDescription.text = comissionDescription
        val color = ArgbEvaluator().evaluate(
            commisionPercent.toFloat() / seekBarComission.max,
            ContextCompat.getColor(this, R.color.color_worst_comission),
            ContextCompat.getColor(this, R.color.color_best_comission)
        ) as Int
        tvComissionDescription.setTextColor(color)
    }

    private fun computeTipAndTotal() {
        if(etBaseAmount.text.isEmpty()){
            tvComissionAmount.text = ""
            tvTotalAmount.text = ""
            return
        }
        val baseAmount = etBaseAmount.text.toString().toDouble()
        val ComissionPercent = seekBarComission.progress

        val ComissionAmount = baseAmount * ComissionPercent / 100
        val TotalAmount = baseAmount + ComissionAmount

        tvComissionAmount.text = "%.2f".format(ComissionAmount)
        tvTotalAmount.text = "%.2f".format(TotalAmount)
    }
}